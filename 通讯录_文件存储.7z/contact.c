#include "contact.h"

void CheckCapacity(Contact *ps){
    if (ps->sz >= ps->capacity){
        // 增容
        PeoInfo *ptr = realloc(ps->data, (ps->capacity + 2)*sizeof(PeoInfo));//realloc将原有数据“保留”增容后初识结构体地址不变。每次扩容仅扩大2个PeoInfo结构体内容大小
        if (ptr != NULL){
            ps->data = ptr;
            ps->capacity += 2;
            printf("增容成功!\n");
        }
        else{
            printf("增容失败!\n");
        };
    }
}

void LoadContact(Contact *ps){
    FILE *pfRead = fopen("contact.dat", "rb");
    if (pfRead == NULL){
        printf("Load::%s\n", strerror(errno));
        return;
    }
    //读取文件
    PeoInfo tmp = { 0 };
    while (fread(&tmp, sizeof(PeoInfo), 1, pfRead)){
        CheckCapacity(ps);
        ps->data[ps->sz] = tmp;
        ps->sz++;
    }
    fclose(pfRead);
    pfRead = NULL;
}

void InitContact(Contact *ps){
    ps->data = (PeoInfo *)malloc(DEFAULT_SZ * sizeof(PeoInfo));//动态内存开辟一段3倍于基础结构体PeoInfo大小的连续内存空间
    if (ps->data == NULL){//如果内存开辟失败，将在屏幕输出打印
        printf("%s\n", strerror(errno));
        return;
    }
    ps->sz = 0;//初始化的时候当前数据量为0
    ps->capacity = DEFAULT_SZ;//当前通讯录的最大容量
    //把文件已经存放的通讯录信息进行加载
    LoadContact(ps);
}

void AddContact(Contact *ps){
#if 0
    if (ps->sz == MAX){
		printf("OverFlow!\n");
	}
	else{
		printf("Input name:");
		scanf("%s", ps->data[ps->sz].name);
		printf("Input age:");
		scanf("%d", &ps->data[ps->sz].age);
		printf("Input sex:");
		scanf("%s", ps->data[ps->sz].sex);
		printf("Input tele:");
		scanf("%s", ps->data[ps->sz].tele);
		printf("Input addr:");
		scanf("%s", ps->data[ps->sz].addr);
		ps->sz++;
		printf("AddContact success!\n");
	}
#endif
    //1.检查当前通讯录的容量
    //1.1满了--》增加空间
    CheckCapacity(ps);
    //增加数据
    printf("Input name:");
    scanf("%s", ps->data[ps->sz].name);
    printf("Input age:");
    scanf("%d", &ps->data[ps->sz].age);
    printf("Input sex:");
    scanf("%s", ps->data[ps->sz].sex);
    printf("Input tele:");
    scanf("%s", ps->data[ps->sz].tele);
    printf("Input addr:");
    scanf("%s", ps->data[ps->sz].addr);
    ps->sz++;
    printf("AddContact success!\n");
}

void ShowContact(const Contact *ps){
    if (ps->sz == 0){
        printf("Contact Empty!\n");
    }
    else{
        printf("%-7s\t%-4s\t%-5s\t%-12s\t%-20s\n", "名字", "年龄", "性别", "电话", "地址");
        for (int i = 0; i < ps->sz; ++i){
            printf("%-7s\t%-4d\t%-5s\t%-12s\t%-20s\n",
                   ps->data[i].name,
                   ps->data[i].age,
                   ps->data[i].sex,
                   ps->data[i].tele,
                   ps->data[i].addr);
        }
    }
}

static int FindByName(const Contact *ps, char *name){
    int i;
    for (i = 0; i < ps->sz; i++)
    {
        if (0 == strcmp(name, ps->data[i].name)){
            return i;
        }
    }
    return -1;
}

void DelContact(Contact *ps){
    char name[MAX_NAME];
    printf("Input del name:");
    scanf("%s", &name);
    // 1.查找要删除的人在什么位置
    int pos = FindByName(ps, name);
    //2.删除
    if (pos == ps->sz){
        printf("no name!\n");
    }
    else{
        // 删除数据
        for (int j = pos; j < ps->sz - 1; ++j){
            ps->data[j] = ps->data[j + 1];
        }
        ps->sz--;
        printf("Del success!\n");
    }
}

void SearchContact(const Contact *ps){
    char name[MAX_NAME];
    printf("Input find name:");
    scanf("%s", &name);
    int pos = FindByName(ps, name);
    if (pos == -1){
        printf("No find!\n");
    }
    else{
        printf("%-7s\t%-4s\t%-5s\t%-12s\t%-20s\n", "名字", "年龄", "性别", "电话", "地址");
        printf("%-7s\t%-4d\t%-5s\t%-12s\t%-20s\n",
               ps->data[pos].name,
               ps->data[pos].age,
               ps->data[pos].sex,
               ps->data[pos].tele,
               ps->data[pos].addr);
    }
}

void ModifyContact(Contact *ps){
    char name[MAX_NAME];
    printf("Input del name:");
    scanf("%s", &name);
    // 1.查找要删除的人在什么位置
    int pos = FindByName(ps, name);
    if (pos == -1){
        printf("No find!\n");
    }
    // 2.修改
    printf("Input name:");
    scanf("%s", ps->data[pos].name);
    printf("Input age:");
    scanf("%d", &ps->data[pos].age);
    printf("Input sex:");
    scanf("%s", ps->data[pos].sex);
    printf("Input tele:");
    scanf("%s", ps->data[pos].tele);
    printf("Input addr:");
    scanf("%s", ps->data[pos].addr);
    printf("ModifyContact success!\n");
}

//每次仅 1 字节交换规则交换
void swap(char *dst, char *src, int sz){
    char tmp;
    while (sz--){
        tmp = *dst;
        *dst = *src;
        *src = tmp;
        ++dst, ++src;
    }
}

//自己编写的qsort，通过冒泡实现的排序
void my_qsort(void *base, int num, int width, int(*cmp)(const void *e1, const void *e2)){
    assert(base && cmp);
    char *tmp = (char *)base;
    int flag = 1;
    for (int i = 0; i < num; ++i){
        flag = 1;
        for (int j = 0; j < num - 1; ++j){
            if (cmp(tmp + j*width, tmp + (j + 1)*width) < 0){
                flag = 0;
                swap(tmp + j*width, tmp + (j + 1)*width, width);
            }
        }
        if (!flag){
            break;
        }
    }
}

//排序方法
int cmp_PeoInfo_By_Name(const void *e1, const void *e2){
    return strcmp(((PeoInfo *)e1)->name, ((PeoInfo *)e2)->name);
}

//调用排序函数
void SortContact(Contact *ps){
    my_qsort(ps->data, ps->sz, sizeof(ps->data[0]), cmp_PeoInfo_By_Name);
    printf("排序成功!\n");
}

//销毁
void DestoryContact(Contact *ps){
    free(ps->data);
    ps->data = NULL;
    printf("Destory success!\n");
}

//写文件
void SaveContact(Contact *ps){
    FILE *pfWrite = fopen("contact.dat", "wb");
    if (pfWrite == NULL){
        printf("Save::%s\n", strerror(errno));
        return;
    }
    for (int i = 0; i < ps->sz; ++i){
        fwrite(&(ps->data[i]), sizeof(PeoInfo), 1, pfWrite);
    }
    printf("Save success!\n");
    fclose(pfWrite);
    pfWrite = NULL;
}