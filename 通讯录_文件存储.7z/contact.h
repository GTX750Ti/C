#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>
#include <string.h>//用于结构体排序的strcmp字符串比较
#include <stdlib.h>//用于动态内存开辟malloc和realloc
#include <errno.h>// 用于动态内存开辟失败后贴出内存报错原因输出，errno
#include <assert.h>

#define MAX 1000
#define MAX_NAME 20
#define MAX_SEX 5
#define MAX_TELE 12
#define MAX_ADDR 30
#define DEFAULT_SZ 3

typedef struct PeoInfo{
    char name[MAX_NAME];
    int age;
    char sex[MAX_SEX];
    char tele[MAX_TELE];
    char addr[MAX_ADDR];
}PeoInfo;

typedef struct Contact{
    PeoInfo *data;//指向通讯录结构体的指针
    int sz;//当前通讯录的数据量
    int capacity;//当前通讯录的最大容量
}Contact;

//枚举类型数据不初始化会从0开始，是为了再main.c中表明对应的case的操作程序，使得代码更清晰明了
enum{
    EXIT,//0
    ADD,//1
    DEL,
    SEARCH,
    MODIFY,
    SHOW,
    SORT,
    DESTORY,
    SAVE,
};

//对应功能函数申明
// 结构体初始化
void InitContact(Contact *ps);
//增加数据
void AddContact(Contact *ps);
//打印数据
void ShowContact(const Contact *ps);
//删除数据
void DelContact(Contact *ps);
//查找数据
void SearchContact(const Contact *ps);
//修改数据
void ModifyContact(Contact *ps);
//排序通讯里【按照名称排序】
void SortContact(Contact *ps);
//清空通讯录
void DestoryContact(Contact *ps);
//写文件
void SaveContact(Contact *ps);
//加载文件信息到通讯录
void LoadContact(Contact *ps);
