#include "contact.h"

void InitContact(Contact *ps){
	memset(ps->data, 0, sizeof(ps->data));
	ps->sz = 0;
}

void AddContact(Contact *ps){
	if (ps->sz >= MAX){
		printf("OverFllow!\n");
	}
	else{
		printf("Input name:");
		scanf("%s", ps->data[ps->sz].name);
		printf("Input age:");
		scanf("%d", &ps->data[ps->sz].age);
		printf("Input sex:");
		scanf("%s", ps->data[ps->sz].sex);
		printf("Input tele:");
		scanf("%s", ps->data[ps->sz].tele);
		printf("Input addr:");
		scanf("%s", ps->data[ps->sz].addr);
		ps->sz++;
		printf("AddContact success!\n");
	}
}

void ShowContact(const Contact *ps){
	if (ps->sz == 0){
		printf("Contact Empty!\n");
	}
	else{
		printf("%-7s\t%-4s\t%-5s\t%-12s\t%-20s\n", "����", "����", "�Ա�", "�绰", "��ַ");
		for (int i = 0; i < ps->sz; ++i){
			printf("%-7s\t%-4d\t%-5s\t%-12s\t%-20s\n",
				ps->data[i].name,
				ps->data[i].age,
				ps->data[i].sex,
				ps->data[i].tele,
				ps->data[i].addr);
		}
	}
}

static int FindByName(const struct Contact *ps, char *name){
	int i;
	for (i = 0; i < ps->sz; i++)
	{
		if (0 == strcmp(name, ps->data[i].name)){
			return i;
		}
	}
	return -1;
}

void DelContact(Contact *ps){
	char name[MAX_NAME];
	printf("Input del name:");
	scanf("%s", &name);
	// 1.����Ҫɾ��������ʲôλ��
	int pos = FindByName(ps, name);
	//2.ɾ��
	if (pos == ps->sz){
		printf("no name!\n");
	}
	else{
		// ɾ������
		for (int j = pos; j < ps->sz - 1; ++j){
			ps->data[j] = ps->data[j + 1];
		}
		ps->sz--;
		printf("Del success!\n");
	}
}

void SearchContact(const Contact *ps){
	char name[MAX_NAME];
	printf("Input find name:");
	scanf("%s", &name);
	int pos = FindByName(ps, name);
	if (pos == -1){
		printf("No find!\n");
	}
	else{
		printf("%-7s\t%-4s\t%-5s\t%-12s\t%-20s\n", "����", "����", "�Ա�", "�绰", "��ַ");
		printf("%-7s\t%-4d\t%-5s\t%-12s\t%-20s\n",
			ps->data[pos].name,
			ps->data[pos].age,
			ps->data[pos].sex,
			ps->data[pos].tele,
			ps->data[pos].addr);
	}
}

void ModifyContact(Contact *ps){
	char name[MAX_NAME];
	printf("Input del name:");
	scanf("%s", &name);
	// 1.����Ҫɾ��������ʲôλ��
	int pos = FindByName(ps, name);
	if (pos == -1){
		printf("No find!\n");
	}
	// 2.�޸�
	printf("Input name:");
	scanf("%s", ps->data[pos].name);
	printf("Input age:");
	scanf("%d", &ps->data[pos].age);
	printf("Input sex:");
	scanf("%s", ps->data[pos].sex);
	printf("Input tele:");
	scanf("%s", ps->data[pos].tele);
	printf("Input addr:");
	scanf("%s", ps->data[pos].addr);
	printf("ModifyContact success!\n");
}

void swap(char *dst, char *src, int sz){
	char tmp;
	while (sz--){
		tmp = *dst;
		*dst = *src;
		*src = tmp;
		++dst, ++src;
	}
}

void my_qsort(void *base, int num, int width, int(*cmp)(const void *e1, const void *e2)){
	assert(base && cmp);
	char *tmp = (char *)base;
	int flag = 1;
	for (int i = 0; i < num; ++i){
		flag = 1;
		for (int j = 0; j < num - 1; ++j){
			if (cmp(tmp + j*width, tmp + (j + 1)*width) > 0){
				flag = 0;
				swap(tmp + j*width, tmp + (j + 1)*width, width);
			}
		}
		if (!flag){
			break;
		}
	}
}

int cmp_PeoInfo_By_Name(const void *e1, const void *e2){
	return strcmp(((PeoInfo *)e1)->name, ((PeoInfo *)e2)->name);
}

void SortContact(Contact *ps){
	my_qsort(ps->data, ps->sz, sizeof(ps->data[0]), cmp_PeoInfo_By_Name);
	printf("����ɹ�!\n");
}
