#include "contact.h"

void menu(){
	printf("*************************\n");
	printf("****1.add       2.del****\n");
	printf("****3.search    4.modify*\n");
	printf("****5.show      6.sort***\n");
	printf("****7.Destory   8.Save***\n");
	printf("****0.exit      *********\n");
}

int main(){
	// ����ͨѶ¼��
	Contact con;
	// ��ʼ��ͨѶ¼
	InitContact(&con);
	int input = 0;
	do{
		menu();
		printf("Select:");
		scanf("%d", &input);
		switch (input){
		case EXIT:
			printf("Exit success!\n");
			break;
		case ADD:
			AddContact(&con);
			break;
		case DEL:
			DelContact(&con);
			break;
		case SEARCH:
			SearchContact(&con);
			break;
		case MODIFY:
			ModifyContact(&con);
			break;
		case SHOW:
			ShowContact(&con);
			break;
		case SORT:
			SortContact(&con);
			break;
		case DESTORY:
			DestoryContact(&con);
			break;
		case SAVE:
			SaveContact(&con);
			break;
		default:
			printf("Select error!\n");
			break;
		}
	} while (input);
}
